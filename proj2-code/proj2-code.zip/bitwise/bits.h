// DO NOT MODIFY THIS FILE
int minusOne();
int test_minusOne();
int thirdBits();
int test_thirdBits();
int byteSwap(int, int, int);
int test_byteSwap(int, int, int);
int copyLSB(int);
int test_copyLSB(int);
int isPositive(int);
int test_isPositive(int);
unsigned floatNegate(unsigned);
unsigned test_floatNegate(unsigned);
int anyEvenBit();
int test_anyEvenBit();
int isAsciiDigit(int);
int test_isAsciiDigit(int);
int floatIsLess(unsigned, unsigned);
int test_floatIsLess(unsigned, unsigned);
int logicalShift(int, int);
int test_logicalShift(int, int);
int greatestBitPos(int);
int test_greatestBitPos(int);
unsigned floatScale1d2(unsigned);
unsigned test_floatScale1d2(unsigned);
// DO NOT MODIFY THIS FILE
